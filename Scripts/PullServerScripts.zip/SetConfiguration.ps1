﻿# Get certificate previously deployed during provisioning 
$psDscCert = Get-ChildItem CERT:\LocalMachine\MY\ | where {$_.Subject -eq "CN=PSDSCPullServerCert"}



# Creates a deterministic GUID based on a name (configuration name, computer name etc..)
function GetIDForName($name)
{
    $md5 = new-object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider
    $utf8 = new-object -TypeName System.Text.UTF8Encoding
    [byte[]]$hash = $md5.ComputeHash($utf8.GetBytes($name.ToLower()))
    $configurationId = New-Object System.Guid -ArgumentList (,$hash)
    return $configurationId
}


Function SetConfiguration
{
    param(
      $Configuration
    )

    $stagingPath = "C:\Program Files\WindowsPowerShell\DscService\Configuration"


    $configurationId = GetIDForName -name $Configuration

    Write-Host "Saving Configuration $Configuration with ID $configurationId in $stagingPath " -ForegroundColor Green

    # Enable saving encrypted password to file 
    $Global:AllNodes =
    @{
        AllNodes = @( 
            @{  
                NodeName      = "$configurationId"
                CertificateID = $psDscCert.Thumbprint
            }
        )
    }

    Write-Host "Specifying cert for decryption:" $psDscCert.Thumbprint

    # Execute the configuration for the node 
    $output = (& $Configuration -node $configurationId -outputpath $stagingPath -ConfigurationData $Global:AllNodes)

    $mofPath =  (Join-Path $stagingPath "$configurationId.mof")
    $mofCheckSumPath = (Join-Path $stagingPath "$configurationId.mof.checksum")
    if((Test-Path $mofCheckSumPath) -eq $true)
    {
        Remove-Item $mofCheckSumPath
    }

    
    New-Item $mofCheckSumPath -type file
    [System.IO.File]::AppendAllText($mofCheckSumPath, (Get-FileHash ($mofPath)).Hash)

    Write-Host "Saved checksum file $mofPath" -ForegroundColor Green


}